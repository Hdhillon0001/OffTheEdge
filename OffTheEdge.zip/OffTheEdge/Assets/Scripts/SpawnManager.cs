﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    float posx,posz;
    private float spwanrange = 9;
    public GameObject enemeyObject;
  private  Vector3 position;
    int enemyCount;
    int spwanNumber;
    // Start is called before the first frame update
    void Start()
    {

        //      InvokeRepeating("spwan", 2, 5);

        

        spwan(2);
    }

    // Update is called once per frame
    void Update()
    {

      
        enemyCount = FindObjectsOfType<Enemy>().Length;
        if (enemyCount == 0)
        {
            spwanNumber++;
            Debug.Log(enemyCount);
            spwan(spwanNumber);
        }
        
          
    }

  private Vector3 SpwanReturnPos()
    {
        posx = (Random.Range(spwanrange, -spwanrange));
        posz = Random.Range(spwanrange, -spwanrange);
        position = new Vector3(posx, 0, posz);
        return position;
    }
    void spwan(int enemieTospwan)
    {
        for (int i = 0; i < enemieTospwan; i++) 
        {
            Instantiate(enemeyObject, SpwanReturnPos(), transform.rotation);
            
        }
    }
  

  

}
