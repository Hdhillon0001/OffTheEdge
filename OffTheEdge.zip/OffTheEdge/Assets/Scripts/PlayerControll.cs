﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControll : MonoBehaviour
{
    public float speed = 1;
    float boost =11;
    Rigidbody rb;
    private GameObject focalpoint;
    bool powerupInUse;
     GameObject indicator;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        focalpoint = GameObject.Find("FocalPoint");
        indicator = GameObject.Find("Rings");
        indicator.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {

        indicator.transform.position = transform.position + new Vector3(0, -0.5f, 0);
        float forwardInput = Input.GetAxis("Vertical");
        float sideInput = Input.GetAxis("Horizontal");
        
        rb.AddForce(focalpoint.transform.forward * speed * forwardInput);
        rb.AddForce(focalpoint.transform.right * speed * sideInput);
        //  transform.Translate(Vector3.forward * speed * forwardInput);
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(focalpoint.transform.forward * speed * forwardInput*boost);
           
        }


    }

    private void OnTriggerEnter(Collider otherObject)
    {
        if (otherObject.CompareTag("Powerup"))
        {
            powerupInUse = true;
            Destroy(otherObject.gameObject);
            StartCoroutine(PowerupCountdown());
            indicator.SetActive(true);
        }
    }


    IEnumerator PowerupCountdown()
    {
        yield return new WaitForSeconds(7);
        powerupInUse = false;
        indicator.SetActive(false);
        
    }
    private void OnCollisionEnter(Collision collision)
    {
    
        if (collision.collider.CompareTag("Enemy"))
        {
            Debug.Log("enemy");
        }
       
        if (collision.collider.CompareTag("Enemy") && powerupInUse)
        {
            float pushforce = 15;
            Rigidbody rbEnemy = collision.gameObject.GetComponent<Rigidbody>();
            Vector3 pushPos = collision.gameObject.transform.position - transform.position;

            rbEnemy.AddForce(pushPos * pushforce, ForceMode.Impulse);

            Debug.Log("enemy phuck you");
        }
    }
}
